##Projekt 3 - pogodynka
Funkcjonalności: 

Do wyboru: 

Wersja '********* nie robię':  

Aplikacja powinna umożliwiać pokazywanie pogody z różnych miejsc na świecie (temp, wilgotność, odpowiednia grafika względem pogody  np. chmurka, słoneczko, deszcz, śnieg etc – minimum to temp, wilg, ciśnienie). Wskazane przez użytkownika miejsca powinny być zapamiętane (localStorage). 

 
 

Wersja 'Last christmas I gave you...':  

j/w + automatyczna aktualizacja pogody co np. 2min. 

 
Wersja 'I am Sparta!': 
j/w  + wykres/tabela pogody godzinowej (np. najbliższe 12 godzin) 

 

Do pobrania danych pogodowych możesz wykorzystać serwis openweathermap (przykład z lab.) 

 

Jeśli wyświetlasz chmurki możeszy wykorzystać ikony pogody: 

https://openweathermap.org/weather-conditions lub np. freepik.com 