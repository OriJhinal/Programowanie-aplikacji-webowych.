##Projekt 2 - DrumKit
Przykładowe dźwięki:
`Dźwięki z 99sounds.org`

Funkcjonalności:
1. Naciśnięcie klawisza na klawiaturze odtwarza dźwięk (należy zaprogramować kilka dźwięków do kilku klawiszy)
2. Możliwość nagrywania dźwięków - 4 osobne kanały nagrywania
3. Możliwość jednoczesnego odtworzenia jednego lub wybranych/wszystkich kanałów
4. Przyjazna forma graficzna
