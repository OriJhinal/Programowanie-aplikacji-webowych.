export enum storageType {
    AppLocalStorage,
    AppFirestorageStorage
}

export const config = {
    storageType: storageType.AppFirestorageStorage
}