export const firebaseConfig = {
    apiKey: "AIzaSyDb3bzx6eX5Rujl0tndYzYUEhvQNFaQv-Q",
    authDomain: "cw04notes.firebaseapp.com",
    projectId: "cw04notes",
    storageBucket: "cw04notes.appspot.com",
    messagingSenderId: "300342835452",
    appId: "1:300342835452:web:cc9ba70d472608aa7aff79",
    measurementId: "G-SQ4QCPG6Q1"
  };